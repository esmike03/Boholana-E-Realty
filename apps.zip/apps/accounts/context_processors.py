    # apps/accounts/context_processors.py

def unread_chat_count(request):
        if request.user.is_authenticated and request.user.role in [
            'broker', 'admin', 'staff', 'sale_assistant'
        ]:
            from apps.reservations.models import ChatMessage
            count = ChatMessage.objects.filter(
                receiver=request.user,
                is_read=False
            ).count()
            return {'total_unread_chat': count}
        return {'total_unread_chat': 0}

def notifications(request):
        if request.user.is_authenticated:
            from apps.accounts.models import Notification
            recent = Notification.objects.filter(
                recipient=request.user
            ).order_by('-created_at')[:10]

            unread_count = Notification.objects.filter(
                recipient=request.user,
                is_read=False
            ).count()

            return {
                'navbar_notifications': recent,
                'navbar_unread_count': unread_count,
            }
        return {
            'navbar_notifications': [],
            'navbar_unread_count': 0,
        }